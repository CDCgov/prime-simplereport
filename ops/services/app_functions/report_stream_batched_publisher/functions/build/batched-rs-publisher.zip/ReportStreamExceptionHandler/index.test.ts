describe("main function export", () => {
    it("calls the SimpleReport webhook API", async () => {
        expect(0).toBe(1);
    });
});