Dev Requirements
- [Azure Function tools](https://github.com/Azure/azure-functions-core-tools)


### Deploy Application
`npm run deploy`
From the global terraform scope `ops/global`
- `terraform apply`